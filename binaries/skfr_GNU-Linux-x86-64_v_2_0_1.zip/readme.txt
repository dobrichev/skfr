"Sudoku Explainer" (SE, serate) is a "quasi standard" in puzzles rating for years.
SE is very slow and not easy to extend.
Sudoku Fast Rating (skfr, this project) is a C++ program rating using as a basis the same set of rules,
but open to new features and designed to be much faster.



The source code and some binary downloads are available at
http://code.google.com/p/skfr-sudoku-fast-rating/

There is a discussion page in New Sudoku Players forum at
http://forum.enjoysudoku.com/projects-skfr-fast-rating-and-sudoku-multi-purpose-program-t30132.html 



skfr_v_2_0_1 is a updated version of skfr, made from source as of October 16, 2012 Rev. r191, about one year after the active development.


The user must be aware of several points:
- The command line specifications are not tested.
- A list of available command is given below.
- Ratings given by skfr are close but not identicel to serate ratings.
- Skfr did not reproduce some bugs of serate in the search of "y cycles" effects.
This can create significant deviations for ratings involving such effects.
- Generally speaking, skfr performs normally better than serate and finds often ratings 0.1 below serate.
- Depending on the area skfr rates at minimum 50 times faster than serate, often between 100 and 1000 times faster than serate


Command line:

Warning: the commands below are not tested in the recent versions and some of them may be outdated or affected by bugs or undocumented features.

Skfr has a default input file "puz.txt"
The user in general should provide its own filename.
Three files will use that name

- input file say "xxx.txt"
- first output xxx_rat.txt containing
  either the rated puzzles
  or the selection 1 in case a split of the input file was ordered
- second output xxx_Nrat.txt containing 
  either the unrated puzzles
  or the selection 2 in case a split of the input file was ordered

_ log file
  the user should not ask to get a log file (command -t)
  but in case he would do that, a log file with the name xxx_log.txt is created
  the log file is dedicated to debugging. As it is, it's not easy to decipher


warning: some of these commands have not yet been used
         creating a risk of bug
have been commonly used

  -d -D -p -P "d<6.5" -n(2)9.5 -i"name"

 
* -i input file also --input=
     don't forget to pu it within "" if the name has blanks
     -i"my file" is valid
     "-imy file" is valid
     -imy file  is not valid
     -imyfile would be valid (name without blank)
     -i "my file" is not valid


 * -d   stop if not diamond 
        also --diamond
 * -p   stop if not pearl 
        also --pearl
 * -D   same as diamond possible deviation 0.2

 * -P   same as pearl possible deviation 0.2


* warning: all commands using the signs < > must be given within " "  eg "-d<6.2"
 


 * -d>  stop if ED lower than     eg  "-d>8.5"
 * -d<  stop if ED higher than    eg  "-d<6.5"
 * -p>  stop if EP lower than     eg  "-p>8.5"
 * -p<  stop if EP higher than    eg  "-d<6.5"
 * -r<  stop if ER higher than    eg  "-r<6.5"


 * -t   create a log file (test mode) 
        please don't use it, this is for debugging purpose

 * -s   split treatment if d< or d> (or both) defined 
        forced if -n()   (see below) is defined



 * -n()xx.y  if after n cycles highest rating still lower than xx.y
 *      forces split mode
        in that mode, ratings given in file -rat are not the final ones
        file _Nrat contains the upper part of the ratings


 * -e  elapsed time per puzzle 
       (total elapsed time is allways given)


Note ; no command is given to have a formated output.
       if ER;EP;ED are given (in -s mode they usually are not)
       the output format is puzzle ED=../../..
       followed by ;time with the option -e
 

   ==============================

 * here a set of command normally unused except if one works in the upper ratings

 * only one of the following limitations should be given, 
 * the last one in the command line will act

 * --NoMul stop evaluation at "multi chains" (excluded)  
 * --NoDyn stop evaluation at "dynamic" (excluded)  
 * --NoDPlus stop evaluation at "dynamic plus" (excluded)  
 * --NoLevel2 stop evaluation at "Nested level 2" (excluded)  
 * --NoLevel3 stop evaluation at "Nested level 3" (excluded)  
 * --NoLevel4 stop evaluation at "Nested level 4" (excluded)  
 
*
 * -Q   Quick classification for nested level 
 *


Known issues:

- Any debug output is incompatible with the parallel execution. Parallel execution is managable only by shell variables, see OpenMP documentation.
- There are minor deviations to serate rating and also to older versions. In general few percents of puzzles are rated -0.1/-0.2 and very rare are rated +0.1.
