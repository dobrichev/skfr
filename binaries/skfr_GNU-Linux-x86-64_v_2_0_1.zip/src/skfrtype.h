#pragma once

namespace skfr {

typedef unsigned short int  USHORT;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned char UCHAR;

} //namespace skfr