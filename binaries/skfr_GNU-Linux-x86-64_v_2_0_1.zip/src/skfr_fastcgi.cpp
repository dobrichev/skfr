//generates a FastCGI application
#if 0
#include "ratingengine.h"
#include <stdio.h>
#include <ostream>

namespace skfr {

//struct puzzleToRate {
//	int er;
//	int ep;
//	int ed;
//	char p[81];
//};
//
//void rateManyPuzzles(int nPuzzles, puzzleToRate *p);

void do_fcgi_job(const char * params, const char *data, std::ostream &out) {
	int nPuzzles;
	sscanf(params, "%d", &nPuzzles);
	int dataSize = strlen(data);
	if(dataSize < nPuzzles * 81)
		return;
	puzzleToRate *puzzlesToRate = (puzzleToRate*)malloc(nPuzzles * sizeof(puzzleToRate));
	for(int i = 0; i < nPuzzles; i++) {
		memcpy(puzzlesToRate[i].p, &data[i * 81], 81);
	}
	rateManyPuzzles(nPuzzles, puzzlesToRate);
	out << "parameters=" << nPuzzles;
	out << "&data=";
	for(int i = 0; i < nPuzzles; i++) {
		memcpy(puzzlesToRate[i].p, &data[i * 81], 81);
		out << "(" << puzzlesToRate[i].er << "," << puzzlesToRate[i].ep << "," << puzzlesToRate[i].ed << ")";
	}
	free(puzzlesToRate);
}

} //namespace skfr

#endif